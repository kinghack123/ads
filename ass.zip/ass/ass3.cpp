#include <iostream>
using namespace std;

// Simple Queue implementation using a struct and array
struct Queue {
    int front, rear;
    int arr[100]; // Fixed size queue

    Queue() {
        front = -1;
        rear = -1;
    }

    void enQueue(int val) {
        if (rear == 99) {
            cout << "Queue Overflow\n";
            return;
        }
        if (front == -1)
            front = 0;
        arr[++rear] = val;
    }

    int deQueue() {
        if (front == -1 || front > rear) {
            cout << "Queue Underflow\n";
            return -1;
        }
        return arr[front++];
    }

    bool isEmpty() {
        return (front == -1 || front > rear);
    }
};

// Node structure for adjacency list
struct AdjListNode {
    int dest;
    struct AdjListNode* next;
};

// Adjacency List
struct AdjList {
    struct AdjListNode* head;
};

// Graph using adjacency list
struct Graph {
    int V;
    struct AdjList* total; // Array of adjacency lists
    int* visited_array;

    Graph(int no_of_vertices) {
        V = no_of_vertices;
        total = new AdjList[V]; // Allocate memory dynamically
        visited_array = new int[V];

        for (int i = 0; i < V; i++) {
            total[i].head = NULL;
            visited_array[i] = 0;
        }
    }

    ~Graph() {
        for (int i = 0; i < V; i++) {
            AdjListNode* temp = total[i].head;
            while (temp) {
                AdjListNode* next = temp->next;
                delete temp;
                temp = next;
            }
        }
        delete[] total;
        delete[] visited_array;
    }

    void addEdge(int src, int dest) {
        struct AdjListNode* new_node = new AdjListNode;
        new_node->dest = dest;
        new_node->next = total[src].head;
        total[src].head = new_node;

        struct AdjListNode* nn2 = new AdjListNode;
        nn2->dest = src;
        nn2->next = total[dest].head;
        total[dest].head = nn2;
    }

    void printAdjList() {
        cout << "\nAdjacency List:\n";
        for (int i = 0; i < V; i++) {
            cout << i;
            AdjListNode* temp = total[i].head;
            while (temp != NULL) {
                cout << " -> " << temp->dest;
                temp = temp->next;
            }
            cout << endl;
        }
    }

    void bfs(int start) {
        Queue Q;
        bool* visited = new bool[V](); // Dynamically allocated visited array
        Q.enQueue(start);
        visited[start] = true;

        while (!Q.isEmpty()) {
            int printVertex = Q.deQueue();
            cout << printVertex << " ";
            AdjListNode* temp = total[printVertex].head;
            while (temp != NULL) {
                if (!visited[temp->dest]) {
                    Q.enQueue(temp->dest);
                    visited[temp->dest] = true;
                }
                temp = temp->next;
            }
        }
        cout << endl;
        delete[] visited; // Free allocated memory
    }

    void dfs(int v) {
        cout << v << " ";
        visited_array[v] = 1;
        AdjListNode* temp = total[v].head;
        while (temp != NULL) {
            if (visited_array[temp->dest] == 0)
                dfs(temp->dest);
            temp = temp->next;
        }
    }
};

// Main function
int main() {
    cout << "\nGraph representation using adjacency list..\n";
    Graph g(6);

    cout << "\nAdding edges...\n";
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(0, 3);
    g.addEdge(1, 4);
    g.addEdge(1, 5);
    
    g.printAdjList(); // Print adjacency list after adding edges

    cout << "\nBFS Traversal starting from node 1 : \n";
    g.bfs(1);

    cout << "\nDFS Traversal starting from node 3 : \n";
    g.dfs(3);

    return 0;
}
