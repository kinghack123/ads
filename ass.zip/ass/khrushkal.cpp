#include <iostream>
using namespace std;

// Structure to represent an edge
struct edge {
    int u, v, w;
};

// Find function with path compression
int find(int parent[], int x) {
    if (parent[x] != x)
        parent[x] = find(parent, parent[x]);
    return parent[x];
}

// Union function
void unite(int parent[], int x, int y) {
    parent[find(parent, y)] = find(parent, x);
}

int main() {
    int n;
    cout << "Enter number of departments: ";
    cin >> n;

    int adj[n][n]; // Adjacency matrix
    cout << "Enter the distance matrix:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> adj[i][j];
        }
    }

    edge edges[n * n];
    int e = 0;

    // Create edge list from adjacency matrix (only lower triangle to avoid duplicates)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (adj[i][j] != 0) {
                edges[e++] = {i, j, adj[i][j]};
            }
        }
    }

    // Sort edges by weight using bubble sort (can be optimized)
    for (int i = 0; i < e - 1; i++) {
        for (int j = i + 1; j < e; j++) {
            if (edges[i].w > edges[j].w) {
                swap(edges[i], edges[j]);
            }
        }
    }

    int parent[n];
    for (int i = 0; i < n; i++) {
        parent[i] = i;
    }

    int total = 0, added = 0;

    cout << "\nMST for college departments:\n";
    for (int i = 0; i < e && added < n - 1; i++) {
        int a = edges[i].u;
        int b = edges[i].v;
        int d = edges[i].w;

        if (find(parent, a) != find(parent, b)) {
            unite(parent, a, b);
            cout << "Department " << a << " - Department " << b << " : " << d << " meters\n";
            total += d;
            added++;
        }
    }

    cout << "\nTotal distance required = " << total << " meters\n";

    return 0;
}
