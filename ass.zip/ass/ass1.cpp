#include <iostream>
#include <string>
using namespace std;

// Node structure representing each dictionary entry
struct Node
{
    string key;   // Word or name
    string value; // Meaning or type
    Node *left;   // Left child in BST
    Node *right;  // Right child in BST

    // Constructor to initialize node
    Node(string key, string value)
    {
        this->key = key;
        this->value = value;
        this->left = nullptr;
        this->right = nullptr;
    }
};

// Dictionary class implementing BST
class Dictionary
{
    Node *root;

public:
    // Constructor to initialize empty dictionary
    Dictionary()
    {
        root = nullptr;
    }

    // Insert a new key-value pair into BST
    void insert(string key, string value)
    {
        Node *newNode = new Node(key, value);
        if (!root)
        {
            root = newNode;
            return;
        }

        Node *temp = root;
        Node *parent = nullptr;
        while (temp)
        {
            parent = temp;
            if (key < temp->key)
            {
                temp = temp->left;
            }
            else if (key > temp->key)
            {
                temp = temp->right;
            }
            else
            {
                cout << "Duplicate Entry\n";
                return; // Key already exists
            }
        }
        // Attach new node to the appropriate parent
        if (key < parent->key)
            parent->left = newNode;
        else
            parent->right = newNode;
    }

    // Display dictionary using in-order traversal (sorted order)
    void displayInOrder()
    {
        if (!root)
        {
            cout << "Tree is empty\n";
            return;
        }
        inOrderTraversal(root);
    }

    // Helper: Recursive in-order traversal
    void inOrderTraversal(Node *node)
    {
        if (!node)
            return;
        inOrderTraversal(node->left);
        cout << node->key << ": " << node->value << endl;
        inOrderTraversal(node->right);
    }

    // Delete a word (node) from the BST
    void deleteWord(string key)
    {
        root = deleteNode(root, key);
    }

    // Helper: Delete node and return updated subtree root
    Node *deleteNode(Node *node, string key)
    {
        if (!node)
            return node;

        // Traverse left or right
        if (key < node->key)
        {
            node->left = deleteNode(node->left, key);
        }
        else if (key > node->key)
        {
            node->right = deleteNode(node->right, key);
        }
        else
        {
            // Node with one or no child
            if (!node->left)
            {
                Node *temp = node->right;
                delete node;
                return temp;
            }
            else if (!node->right)
            {
                Node *temp = node->left;
                delete node;
                return temp;
            }

            // Node with two children: Find inorder successor
            Node *successorParent = node;
            Node *successor = node->right;
            while (successor->left)
            {
                successorParent = successor;
                successor = successor->left;
            }

            // Replace current node's key and value
            node->key = successor->key;
            node->value = successor->value;

            // Remove successor node
            if (successorParent->left == successor)
                successorParent->left = successor->right;
            else
                successorParent->right = successor->right;

            delete successor;
        }
        return node;
    }

    // Search for a key and return pointer to node (or nullptr if not found)
    Node *search(string key)
    {
        Node *temp = root;
        while (temp)
        {
            if (temp->key == key)
                return temp;
            else if (key < temp->key)
                temp = temp->left;
            else
                temp = temp->right;
        }
        return nullptr;
    }

    // Mirror the BST by swapping left and right subtrees
    void mirror()
    {
        mirrorTree(root);
        cout << "Tree has been mirrored.\n";
    }

    // Helper: Recursive mirror logic
    void mirrorTree(Node *node)
    {
        if (!node)
            return;
        swap(node->left, node->right);
        mirrorTree(node->left);
        mirrorTree(node->right);
    }

    // Copy the entire BST into a new Dictionary
    Dictionary copy()
    {
        Dictionary newDict;
        newDict.root = copyTree(root);
        cout << "Tree has been copied.\n";
        return newDict;
    }

    // Helper: Recursively copy tree nodes
    Node *copyTree(Node *node)
    {
        if (!node)
            return nullptr;
        Node *newNode = new Node(node->key, node->value);
        newNode->left = copyTree(node->left);
        newNode->right = copyTree(node->right);
        return newNode;
    }

    // Level order (BFS) traversal using custom queue
    void displayLevelOrder()
    {
        if (!root)
        {
            cout << "Tree is empty\n";
            return;
        }

        Node *queue[100]; // Simple static queue
        int front = 0, rear = 0;
        queue[rear++] = root;

        while (front<  rear)
        {
            Node *temp = queue[front++];
            cout << temp->key << ": " << temp->value << endl;
            if (temp->left)
                queue[rear++] = temp->left;
            if (temp->right)
                queue[rear++] = temp->right;
        }
    }
};

// Main function: user menu-driven interface
int main()
{
    int n, m, i, j;
    string key, value;
    Dictionary dev;

    do
    {
        cout << "Choose One of the Options:" << endl
             << "1. Insert the key(name) and value(type)" << endl
             << "2. Display Using Inorder Traversal" << endl
             << "3. Delete a Node" << endl
             << "4. Search for an Element using Key" << endl
             << "5. Mirror the Tree" << endl
             << "6. Copy the Tree" << endl
             << "7. Display Using Level Order Traversal" << endl;
        cin >> n;

        switch (n)
        {
        case 1:
            cout << "Enter number of entries: ";
            cin >> m;
            for (i = 0; i < m; i++)
            {
                cout << "Enter key: ";
                cin >> key;
                cout << "Enter value(type): ";
                cin >> value;
                dev.insert(key, value);
            }
            break;

        case 2:
            dev.displayInOrder();
            break;

        case 3:
            cout << "Enter the key of the node to be deleted: ";
            cin >> key;
            dev.deleteWord(key);
            break;

        case 4:
            cout << "Enter the key of the node to be searched: ";
            cin >> key;
            if (Node *result = dev.search(key))
                cout << "Key found: " << result->key << " -> " << result->value << endl;
            else
                cout << "Key not found\n";
            break;

        case 5:
            dev.mirror();
            break;

        case 6:
        {
            Dictionary copiedTree = dev.copy();
            cout << "Copied tree displayed using in-order traversal:\n";
            copiedTree.displayInOrder();
            break;
        }

        case 7:
            dev.displayLevelOrder();
            break;

        default:
            cout << "Invalid Option\n";
            break;
        }

        cout << "Continue? (1 for Yes / 0 for No): ";
        cin >> j;
    } while (j == 1);

    return 0;
}
