#include <iostream>
#include <climits> // For INT_MAX
using namespace std;

// Structure to store location names
struct Location
{
    char name[30];  // Fixed-size char array
};

// Structure for an edge (node and weight)
struct Edge 
{
    int to;
    int weight;
    Edge* next;
};

// Maximum number of locations (can be adjusted)
const int MAX_LOCATIONS = 5;
const int INF = INT_MAX;

// Adjacency list for the graph
Edge* graph[MAX_LOCATIONS];

// Add edge to the adjacency list
void addEdge(int from, int to, int weight) 
{
    Edge* newEdge = new Edge;
    newEdge->to = to;
    newEdge->weight = weight;
    newEdge->next = graph[from];
    graph[from] = newEdge;
}

// Dijkstra's Algorithm
void dijkstra(int start, Location locations[], int n)
{
    int dist[MAX_LOCATIONS];
    bool visited[MAX_LOCATIONS];

    for (int i = 0; i < n; i++)
    {
        dist[i] = INF;
        visited[i] = false;
    }

    dist[start] = 0;

    for (int count = 0; count < n - 1; count++) 
    {
        int minDist = INF, u = -1;

        for (int i = 0; i < n; i++)
        {
            if (!visited[i] && dist[i] < minDist) 
            {
                minDist = dist[i];
                u = i;
            }
        }

        if (u == -1) break;
        visited[u] = true;

        Edge* ptr = graph[u];
        while (ptr != nullptr) 
        {
            int v = ptr->to;
            int w = ptr->weight;
            if (!visited[v] && dist[u] + w < dist[v])
            {
                dist[v] = dist[u] + w;
            }
            ptr = ptr->next;
        }
    }

    // Output
    cout << "\nShortest distances from the " << locations[start].name << " are :\n\n";
    
    for (int i = 0; i < n; i++)
    {
        cout << "To the " << locations[i].name << ": ";
        if (dist[i] == INF)
            cout << "Unreachable\n";
        else
            cout << dist[i] << " units\n";
    }
}

int main() 
{
    int n = MAX_LOCATIONS;
    Location locations[MAX_LOCATIONS] = 
    {
        {"Supplier"},
        {"Warehouse"},
        {"Distribution Center"},
        {"Retail Store A"},
        {"Retail Store B"}
    };
    for (int i = 0; i < n; i++)
    {
        graph[i] = nullptr;
    }

    // Add edges
    addEdge(0, 1, 4);  // Supplier -> Warehouse
    addEdge(0, 2, 2);  // Supplier -> Distribution Center
    addEdge(1, 3, 5);  // Warehouse -> Retail Store A
    addEdge(2, 1, 1);  // Distribution Center -> Warehouse
    addEdge(2, 3, 8);  // Distribution Center -> Retail Store A
    addEdge(2, 4, 10); // Distribution Center -> Retail Store B
    addEdge(3, 4, 2);  // Retail Store A -> Retail Store B

    int start = 0; // Start from Supplier
    dijkstra(start, locations, n);

    return 0;
}
