
#include <iostream>
using namespace std;

const int MAX = 10;
const int INF = 1e9; // Infinite distance

// Struct for the graph
struct Graph
{
    int nodes; // Number of departments
    int adjMatrix[MAX][MAX]; // Adjacency matrix to store distances
};

// Struct to represent MST results
struct MST
{
    int parent[MAX];  // Stores MST parent of each node
    int key[MAX];     // Stores minimum edge weight to each node
    bool inMST[MAX];  // True if node is included in MST
};

// Function to initialize the graph
void initGraph(Graph &g, int n) 
{
    g.nodes = n;
    for (int i = 0; i < n; ++i)
       {
           for (int j = 0; j < n; ++j)
           {
               g.adjMatrix[i][j] = INF; // No connection initially
           }
       }   
}           

// Function to add an edge (distance between two departments)
void addEdge(Graph &g, int u, int v, int dist) 
{
    g.adjMatrix[u][v] = dist;
    g.adjMatrix[v][u] = dist; // Since it's an undirected graph
}

// Function to find the node with the minimum key value
int minKey(MST &mst, int n)
{
    int min = INF, minIndex = -1;
    for (int v = 0; v < n; v++)
    {
        if (!mst.inMST[v] && mst.key[v] < min) 
        {
            min = mst.key[v];
            minIndex = v;
        }
    }
    return minIndex;
}

// Prim's Algorithm to find MST
void primMST(Graph &g) 
{
    MST mst;

    for (int i = 0; i < g.nodes; i++)
    {
        mst.key[i] = INF;
        mst.inMST[i] = false;
        mst.parent[i] = -1;
    }

    // Start from the first node (department 0)
    mst.key[0] = 0;

    for (int count = 0; count < g.nodes - 1; count++) 
    {
        int u = minKey(mst, g.nodes);
        mst.inMST[u] = true;

        // Update keys and parent for adjacent nodes
        for (int v = 0; v < g.nodes; v++) 
        {
            if (g.adjMatrix[u][v] != INF && !mst.inMST[v] && g.adjMatrix[u][v] < mst.key[v])
            {
                mst.parent[v] = u;
                mst.key[v] = g.adjMatrix[u][v];
            }
        }
    }

    // Print the MST edges and total distance
    int totalCost = 0;
    cout << "\nMinimum Spanning Tree (MST) edges:\n\n";
    for (int i = 1; i < g.nodes; i++)
    {
        cout << "Department " << mst.parent[i] << " - Department " << i
             << " | Distance = " << g.adjMatrix[i][mst.parent[i]] << "\n";
        totalCost += g.adjMatrix[i][mst.parent[i]];
    }

    cout << "\nTotal distance of MST = " << totalCost << "\n";
}

int main()
{
    Graph campus;

    int departments = 5; // Example: 5 departments
    initGraph(campus, departments);

    // Add distances between departments (you can modify these)
    addEdge(campus, 0, 1, 10); // Dept 0 - Dept 1 = 10
    addEdge(campus, 0, 2, 20);
    addEdge(campus, 1, 2, 5);
    addEdge(campus, 1, 3, 15);
    addEdge(campus, 2, 3, 30);
    addEdge(campus, 2, 4, 8);
    addEdge(campus, 3, 4, 6);

    // Find and display MST
    primMST(campus);

    return 0;
}

